
**Q**. What is FTP?

**A**. FTP ( File Transfer Protocol) is a simple, but yet unique way of transfering files from your Android device (mobile or tablet) to a PC wirelessly on a local network.
where, your device acts as a server and your PC is the client.

**Q**. How do i setup FTP on AnExplorer?

**A**. To set up FTP on AnExplorer, click the computer icon in the app's homepage, and there you can setup your FTP.
**Note**: The main requirement for FTP on your device, is that your Android device and PC should be connected to the same Wi-Fi network.
Incase you don’t have the same Wi-Fi network, you can create a hotspot and then use FTP and theres no need for a working internet connection.

**Q**. What's the function of the broom icon?

**A**. The brrom icon stands for cleaning, it clears all opened apps using the phone's ram. thereby freeing up some ram space for smooth performance of the app.
This helps users with low ram memory. 

**Q**. How do i select default storage on my device.

**A**. Click the icon on the internal storage window, this takes you to the storage settings of your device.

**Q**. How do i set file folder size and show hidden files?

**A**. Click the dotted vertical lines at the top right side of the screen **Select settings** **Click general** and tick the box for the folder size and show hidden files.

**Q**. How do i enable pin lock to protect my files from intruders?

**A**. Click on the dotted vertical line Select **settings** Click **security** Click **enable pin protection** Select Set Pin and choose your prefered pin.

**Q**. How do i stop certain apps from using my phone's Ram space?

**A**. Click the menu button at the top left side of the screen, then select either "User Apps" or "System Apps" and click the dotted line at the base of the app you
want to stop or uninstall, then select either "Stop or Uninstall".

**Q**. How do i backup my apps?

**A**. Click the menu button at the top left side of the screen, then select either "User Apps" or "System Apps" and click the dotted line at the base of the app you want to backup, then select **backup**.
Click the menu button at the top left side of the screen, then select either "User Apps" or "System Apps" and click the dotted line at the base of the app you want to backup.

**Q**. Where can i find my backuped files?

**A**. The backup files are saved in the internal memory of your device, under the folder **AppBack**.


# Contact Us

You can contact us via the following:

Email: hakr@dworks.io

Github: https://github.com/1hakr/AnExplorer

Website: https://anexplorer.co
