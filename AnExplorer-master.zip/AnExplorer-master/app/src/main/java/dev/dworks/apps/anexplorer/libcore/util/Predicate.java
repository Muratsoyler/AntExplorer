package dev.dworks.apps.anexplorer.libcore.util;

public interface Predicate<T> {

    boolean apply(T t);
}