package dev.dworks.apps.anexplorer.ui;

public interface ScrollDirectionListener {
    void onScrollDown();
    void onScrollUp();
}